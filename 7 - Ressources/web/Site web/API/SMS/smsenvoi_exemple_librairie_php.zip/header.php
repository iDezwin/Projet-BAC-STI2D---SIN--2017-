<html>
	<head>
	
		<meta charset="utf-8">
			<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
		<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	</head>
	<body>
	
	<header>
		<nav class="navbar navbar-inverse ">
		  <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <a class="navbar-brand" href="#">Plateforme SMS</a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
			  <ul class="nav navbar-nav">
				<li <?php if($menu=='home'){ ?>class="active"<?php } ?>><a href="index.php">Accueil</a></li>
				<li <?php if($menu=='sendsms'){ ?>class="active"<?php } ?>><a href="index.php?page=sendsms">Envoyer un SMS</a></li>
				<li <?php if($menu=='checkdelivery'){ ?>class="active"<?php } ?>><a href="index.php?page=checkdelivery">Consulter le statut d'un envoi</a></li>
				<li><a href="http://www.smsenvoi.com/site/webroot/API/smsenvoi-librairie-php.html" target="_blank">Doc API</a>
				<li><a href="/membres/deconnexion/">Déconnexion</a></li>
 				
		  </ul>
			</div><!--/.nav-collapse -->
		  </div>
		</nav>
	</header>
    <div class="container">
	<div class="starter-template">
