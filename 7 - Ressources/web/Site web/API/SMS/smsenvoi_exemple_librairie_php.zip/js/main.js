
$(document).ready(function(){
	
	$("#message_content").keyup(function(){ longueur=comptecaracteres(); if(longueur<=1){ $("#nb_caracteres").html(longueur+" caractère");}else{ $("#nb_caracteres").html(longueur+" caractères"); }})
	
	
});


/** comptage de caractères **/
function substr_count( haystack, needle, offset, length ) {

    var pos = 0, cnt = 0;

    if(isNaN(offset)) offset = 0;
    if(isNaN(length)) length = 0;
    offset--;

    while( (offset = haystack.indexOf(needle, offset+1)) != -1 ){
        if(length > 0 && (offset+needle.length) > length){
            return false;
        } else{
            cnt++;
        }
    }

    return cnt;
}



var nbsms=0;
function comptecaracteres(){
	var message=$("#message_content").val();
	message=message.replace('œ','oe');
	message=message.replace('²','');
	$("#message_content").val(message);
	message=message.replace("#URL#","http://se1.fr/xxxx").replace("#url#","http://se1.fr/xxxx"); 
	var longueur=message.length+substr_count(message, "\n");

	return longueur;	
}

/** fin comptage de caratères **/