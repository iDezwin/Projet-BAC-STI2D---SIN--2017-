<h1>Vérifier l'état d'un envoi</h1>
<form method="get" action="index.php">
	<input type="hidden" name="page" value="checkdelivery_process">
  <div class="form-group">
    <label for="message_id">Id de l'envoi</label>
    <input type="text" name="id" class="form-control" id="message_id" placeholder="Id de l'envoi" >
  </div>

  <div class="pull-right">
  <button type="submit" class="btn btn-default">Vérifier</button>
  </div>

</form>