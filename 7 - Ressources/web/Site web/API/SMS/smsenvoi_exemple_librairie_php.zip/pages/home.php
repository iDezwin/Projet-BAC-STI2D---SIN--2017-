<h1>Plateforme d'exemple SMS Envoi</h1>



<div class="well">

Bienvenue sur notre plateforme d'exemple implémentant la librairie PHP SMS Envoi. Il s'agit d'un ensemble de scripts vous permettant de vous familiariser avec notre librairie PHP et de vous permettre de mettre en place votre propre interface d'envoi de SMS en un temps record.

Les envois effectués depuis cette interface en ligne sont décomptés de votre compte client.<br><br>

Attention : bien que le code source téléchargeable de cet exemple soit fonctionnel et prêt à l'emploi, nous vous recommandons fortement d'implémenter un système d'authentification afin de n'autoriser que les personnes habilitées à envoyer des SMS. 

Tout SMS envoyé est décompté du nombre de crédits restants sur le compte paramétré dans le fichier librairie_smsenvoi/smsenvoi.config.php. Vous êtes responsable de l'utilisation faîte de ce code téléchargé tout comme de la confidentialité de votre clef APIKEY permettant de vous authentifier auprès de nos services. De plus, pour profiter pleinement de l'ensemble des fonctionnalités proposées par SMS Envoi, nous vous recommandons d'utiliser une base de données.
<br><br>

</div>