<?php

	if(isset($_POST['message'])){

		//Instantiation de l'objet $smsenvoi appartenant à la classe SMSENVOI
		$smsenvoi=new smsenvoi();
		
		//Envoi du SMS (forcé en gamme premium)
		//renvoie true si succès
		if($smsenvoi->sendSMS($_POST['message']['recipients'],$_POST['message']['content'],'PREMIUM',$_POST['message']['senderlabel'])){
			
				//ENVOI REUSSI
				$success=true;

				//Id de l'envoi effectué
				//Idéalement, cet id devrait être stocké en base de données
				$id_envoi=$smsenvoi->id;
			
		}else{
				//ECHEC
				$success=false;
			
		}
		
		
	}else{ 
		//formulaire non posté ? nous sômmes arrivés ici par erreur
		header("location:/index.php?page=sendsms");
		die();
	}


	
?><h1>Envoyer un SMS</h1>
<br><br>

<div class="panel panel-default"><div class="panel-heading">Résultat de l'envoi:</div>
<div class="panel-body">
<center>

<?php 

if($success){ 
	echo '<b>ENVOI REUSSI</b>';
	echo '<br><br>Id de l\'envoi : '.$id_envoi;
	echo '<br><br><a class="btn btn-default" href="index.php?page=checkdelivery_process&id='.$id_envoi.'">Suivre l\'état de l\'envoi</a>';

}else{ 
	echo '<b>ECHEC DE L\'ENVOI</b>'; 
} ?>

</center>
</div></div>