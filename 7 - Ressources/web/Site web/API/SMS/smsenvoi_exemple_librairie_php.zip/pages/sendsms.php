<h1>Envoyer un SMS</h1>
<form method="post" action="index.php?page=sendsms_process">

  <div class="form-group">
    <label for="message_senderlabel">Expéditeur</label>
    <input type="text" name="message[senderlabel]" class="form-control" id="message_senderlabel" placeholder="nom d'expéditeur" maxlength="11">
  </div>
  <div class="form-group">
    <label for="message_content">Contenu du message</label>
    <textarea class="form-control" id="message_content" name="message[content]" placeholder="Saisissez votre message" maxlength="160" rows="5"></textarea>
	<div id="nb_caracteres" class="pull-right">&nbsp;</div>
  </div>
  <div class="form-group">
    <label for="message_recipients">Destinataire(s)</label>
    <input type="text"  class="form-control" name="message[recipients]" id="message_recipients" pattern="([0-9\+,])+"  placeholder="Numéro du ou des destinataires séparés par des virgules">
  </div>

  <div class="pull-right">
  <button type="submit" class="btn btn-default">Envoyer le SMS</button>
  </div>

</form>
<br><br><center><i>L'envoi sera effectué depuis le compte <?php echo SMSENVOI_EMAIL; ?></i></center>