<?php

	if(!isset($_GET['id'])){
		header("location:/index.php?page=checkdelivery");
		}
	
	$id=intval($id);
	
	//instantiation de l'objet $smsenvoi appartenant à la classe smsenvoi
	$smsenvoi=new smsenvoi();

	//récupération des statuts des SMS envoyés dans le cadre de la campagne $_GET['id]  (id retourné par  $smsenvoi->id lors de l'envoi)
	$result=$smsenvoi->checkdelivery($id);
	

	
	?><h1>Statut de l'envoi <?php echo $_GET['id']; ?>
	
<div class="pull-right"><a href="index.php?page=checkdelivery_process&id=<?php echo $id; ?>" class="btn  btn-primary">Actualiser</a></div>	<br><br>
	<table class="table table-bordered table-striped">
	<thead><tr><th>Destinataire</th><th>Statut</th><th>Date</th><th>Heure</th></tr></thead>
	<?php
	
		//boucle sur l'ensemble des destinataires de l'envoi
		foreach($result as $recipient){
			
				
				
				//pas encore d'A.R.
				if($recipient->arcode==0){
					
						$ardate=''; 
						$artime='';
					
				}else{
					
						$ardate=date("d/m/Y",strtotime($recipient->ardate));
						$artime=$recipient->artime;
					
				}
				
				echo "<tr><td>".$recipient->recipient."</td><td>".$recipient->ar."</td><td>".$ardate."</td><td>".$artime."</td></tr>";
			
			
		}
	
	?>
	
	</table>