<?php
date_default_timezone_set("Europe/Paris");
require_once("librairie_smsenvoi/smsenvoi.php");

if(SMSENVOI_APIKEY==''){ die("Merci d'indiquer l'adresse e-mail associee a votre compte SMS Envoi ainsi que votre APIKEY dans le fichier librairie_smsenvoi/smsenvoi.conf.php"); }


if(!isset($_GET['page'])){$page='home'; }else{ $page=$_GET['page'];  }


switch($page){
	
	//Formulaire d'envoi de SMS
	case 'sendsms':
		$content= "pages/sendsms.php";
		$menu='sendsms';
	break;

	//Envoi de SMS ( utilisation de $smsenvoi->sendSMS() )
	case 'sendsms_process':
		$content= "pages/sendsms_process.php";
		$menu='sendsms';
	break;
	
	//Formulaire de récupération des accusés d'un envoi
	case 'checkdelivery':
		$content= "pages/checkdelivery.php";
		$menu='checkdelivery';
	break;
	
	
	//Récupération des accusés d'un envoi ( utilisation de $smsenvoi->checkDelivery() )
	case 'checkdelivery_process':
		$content= "pages/checkdelivery_process.php";
		$menu='checkdelivery';
	break;
	
	
	//Page d'accueil
	default :
		$content= "pages/home.php";
		$menu='home';
	break;
	
}


include("header.php");
require_once($content);
include("footer.php")


?>


